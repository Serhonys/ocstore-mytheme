<?php
class ControllerExtensionThemeNordic extends Controller {
    public function eventHeader(&$route, &$data, &$code = null) {
        $radius = $this->allowed($this->config->get('theme_nordic_ui_radius'), array('0', '8', '14'), '14');
        $border = $this->allowed($this->config->get('theme_nordic_ui_border'), array('air', 'hairline', 'contrast'), 'hairline');
        $accent = $this->allowed(strtoupper((string)$this->config->get('theme_nordic_ui_accent')), array('#111111', '#16A34A', '#DC2626'), '#111111');
        $gallery = $this->allowed($this->config->get('theme_nordic_ui_gallery'), array('grid', 'slider-left', 'slider-bottom'), 'grid');
        $density = $this->allowed($this->config->get('theme_nordic_ui_density'), array('expanded', 'compact'), 'expanded');
        $cols = $this->allowed($this->config->get('theme_nordic_ui_cols'), array('2', '3', 'list'), '3');

        $borders = array('air' => 'transparent', 'hairline' => '#E5E5E5', 'contrast' => '#111111');
        $hover = array('#111111' => '#262626', '#16A34A' => '#15803D', '#DC2626' => '#B91C1C');

        $class = 'nf-gallery-' . $gallery . ' nf-density-' . $density . ' nf-cols-' . $cols;
        $flags = array('swatches', 'dims', 'installment', 'meta', 'discount', 'urgency', 'shipping', 'oneclick', 'blueprint');

        foreach ($flags as $flag) {
            if ((string)$this->config->get('theme_nordic_ui_' . $flag) === '0') {
                $class .= ' nf-off-' . $flag;
            }
        }

        $data['nf_body'] = $class;
        $data['nf_style'] = '<style id="nf-tokens">:root{'
            . '--ui-radius:' . (int)$radius . 'px;'
            . '--ui-radius-sm:' . max(0, (int)$radius - 4) . 'px;'
            . '--ui-border-color:' . $borders[$border] . ';'
            . '--ui-btn-accent:' . $accent . ';'
            . '--ui-btn-accent-hover:' . $hover[$accent] . ';'
            . '}</style>';
    }

    private function allowed($value, $list, $fallback) {
        $value = (string)$value;

        return in_array($value, $list, true) ? $value : $fallback;
    }
}
