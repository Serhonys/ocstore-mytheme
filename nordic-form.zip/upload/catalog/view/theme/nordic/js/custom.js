$('.top-menu-icon').click(function () {
    $('#top').find('.left-top').slideToggle('fast');
    $(this).toggleClass('active');
    $(this).find('div').removeClass('no-animation');
});
$window = $(window);
$(window).scroll(function () {
    $('.menu-wrapper').toggleClass('fixed', $window.scrollTop() >= 200);
});
$(function () {
    $(window).scroll(function () {
        $(this).scrollTop() > 150 ? $("#back-top").fadeIn() : $("#back-top").fadeOut()
    })
}), jQuery(".backtotop").click(function () {
    jQuery("html, body").animate({scrollTop: 0}, "slow")
});
$('#menu .nav > li > .dropdown-menu, #menu .nav > li > .dropdown-menu > li > .dropdown-menu, #menu .nav > li > .dropdown-menu > li > .dropdown-menu > li > .dropdown-menu').before('<span class="submore"></span>');
$('span.submore').click(function () {
    $(this).next().slideToggle('fast');
    $(this).toggleClass('plus');
});
$('.treeview-list .collapsable ul').css('display','block');
$('.hamburger').on('click', function() {
    $(this).toggleClass('active');
});

$('.btn-callback').on('click', function () {
    $('#modal-callback').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_callback',
        type: 'get',
        dataType: 'html',
        success: function (data) {
            $('#modal-callback .modal-content').prepend(data);
            html = '<div id="modal-callback" class="modal fade">';
            html += '  <div class="modal-dialog modal-sm">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-callback').modal('show');
        }
    });
});

var signin = function () {
    $('#modal-signin').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_login',
        type: 'get',
        dataType: 'html',
        success: function (data) {
            $('#modal-signin .modal-content').prepend(data);
            html = '<div id="modal-signin" class="modal fade">';
            html += '  <div class="modal-dialog modal-sm">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-signin').modal('show');
        }
    });
};

var fastorder = function (product_id) {
    $('#modal-fastorder').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_fastorder',
        type: 'post',
        data: 'product_id=' + product_id,
        dataType: 'html',
        success: function (data) {
            $('#modal-fastorder .modal-content').prepend(data);
            html = '<div id="modal-fastorder" class="modal fade">';
            html += '  <div class="modal-dialog">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-fastorder').modal('show');
        }
    });
};

var preorder = function (product_id) {
    $('#modal-preorder').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_preorder',
        type: 'post',
        data: 'product_id=' + product_id,
        dataType: 'html',
        success: function (data) {
            $('#modal-preorder .modal-content').prepend(data);
            html = '<div id="modal-preorder" class="modal fade">';
            html += '  <div class="modal-dialog">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-preorder').modal('show');
        }
    });
};

var quickview = function (product_id) {
    $('#modal-quickview').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_quickview',
        type: 'post',
        data: 'product_id=' + product_id,
        dataType: 'html',
        success: function (data) {
            $('#modal-quickview .modal-content').prepend(data);
            html = '<div id="modal-quickview" class="modal fade">';
            html += '  <div class="modal-dialog modal-lg">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-quickview').modal('show');
        },
        error: function(xhr, ajaxOptions, thrownError) {
            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
        }
    });
};

var cheaper = function (product_id) {
    $('#modal-cheaper').remove();
    $.ajax({
        url: 'index.php?route=extension/module/mod_cheaper',
        type: 'post',
        data: 'product_id=' + product_id,
        dataType: 'html',
        success: function (data) {
            $('#modal-cheaper .modal-content').prepend(data);
            html = '<div id="modal-cheaper" class="modal fade">';
            html += '  <div class="modal-dialog">';
            html += '    <div class="modal-content">' + data + '</div>';
            html += '  </div>';
            html += '</div>';
            $('body').append(html);
            $('#modal-cheaper').modal('show');
        }
    });
};